import React from 'react';

export default function Footer() {
	return (
		<footer>
            <p>&copy; Julie White | HackerYou 2017</p>
        </footer>	
	)
}
